<?php
/*
Plugin Name: URL Pinger (website live check)
Description: Check live/down status of URLs or Websites by pinging them on set intervals.
Version: 1.20
Author: CodeSmart
Author URI: https://codesmart.online
Requires PHP: 5.6
Requires at least: 4.6
Tested up to: 6.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

if (!defined('ABSPATH')) exit;

// --- Table name helper (shortened for max length 64) ---
function url_pinger_get_table_name()
{
    global $wpdb;
    $proposed = $wpdb->prefix . 'url_pinger';
    if (strlen($proposed) > 64) {
        return $wpdb->prefix . 'urlpgr';
    } else {
        return $proposed;
    }
}

function url_pinger_normalize_url($url)
{
    $url = trim($url);
    $url = preg_replace('#^https?://#i', '', $url);
    $url = preg_replace('#^www\.#i', '', $url);
    $url = rtrim($url, '/');
    return strtolower($url);
}

function url_pinger_format_url($url)
{
    $url = trim($url);
    $url = preg_replace('#^https?://#i', '', $url);
    $url = rtrim($url, '/');
    $parts = explode('/', $url, 2);
    $host = $parts[0];
    $final = 'https://' . $host;
    return $final;
}

if (version_compare(PHP_VERSION, '5.6.0', '<')) {
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>URL Pinger (website live check)</strong> requires PHP version 5.6 or higher. Your current PHP version is ' . esc_html(PHP_VERSION) . '.</p></div>';
    });
    return;
}

register_activation_hook(__FILE__, 'url_pinger_activate');
function url_pinger_activate()
{
    global $wpdb;
    $table = url_pinger_get_table_name();
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        url VARCHAR(255) NOT NULL,
        interval_hours INT NOT NULL,
        last_ping_time DATETIME DEFAULT NULL,
        last_ping_status VARCHAR(10) DEFAULT NULL,
        last_ping_result_time DATETIME DEFAULT NULL,
        is_ignored TINYINT(1) DEFAULT 0
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    if (get_option('url_pinger_admin_email') === false) {
        update_option('url_pinger_admin_email', get_option('admin_email'));
    }
}

// Add new "is_ignored" column to DB if not present (for upgrades)
add_action('plugins_loaded', function () {
    global $wpdb;
    $table = url_pinger_get_table_name();
    $row = $wpdb->get_results("SHOW COLUMNS FROM $table LIKE 'is_ignored'");
    if (empty($row)) {
        $wpdb->query("ALTER TABLE $table ADD COLUMN is_ignored TINYINT(1) DEFAULT 0");
    }
});

add_action('admin_menu', function () {
    add_menu_page(
        'URL Pinger',
        'URL Pinger',
        'manage_options',
        'url-pinger',
        'url_pinger_admin_page',
        'dashicons-admin-site',
        25
    );
});

add_action('admin_init', 'url_pinger_handle_post');
function url_pinger_handle_post()
{
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $table = url_pinger_get_table_name();

    // Handle bulk delete
    if (isset($_POST['url_pinger_bulk_delete']) && !empty($_POST['url_pinger_ids'])) {
        check_admin_referer('url_pinger_bulk_delete');
        $ids = array_map('intval', (array)$_POST['url_pinger_ids']);
        if (!empty($ids)) {
            $in = implode(',', array_fill(0, count($ids), '%d'));
            $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE id IN ($in)", $ids));
        }
        wp_redirect(admin_url('admin.php?page=url-pinger&bulk_deleted=1'));
        exit;
    }

    if (isset($_POST['url_pinger_delete_all'])) {
        check_admin_referer('url_pinger_delete_all');
        $wpdb->query("TRUNCATE TABLE $table");
        wp_redirect(admin_url('admin.php?page=url-pinger&url_pinger_delete_all=1'));
        exit;
    }

    if (isset($_POST['url_pinger_save_email'])) {
        check_admin_referer('url_pinger_save_email');
        $email = sanitize_email(trim($_POST['url_pinger_admin_email']));
        if (is_email($email)) {
            update_option('url_pinger_admin_email', $email);
        }
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }

    if (isset($_POST['url_pinger_add_url'])) {
        check_admin_referer('url_pinger_add_url');
        $original_url = trim($_POST['url_pinger_url']);
        $interval = intval($_POST['url_pinger_interval']);
        if ($original_url && $interval > 0) {
            $formatted_url = url_pinger_format_url($original_url);
            $norm = url_pinger_normalize_url($formatted_url);
            $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table WHERE LOWER(REPLACE(REPLACE(REPLACE(url, 'http://', ''), 'https://', ''), 'www.', '')) = %s", $norm));
            if ($existing) {
                $wpdb->update($table, [
                    'url' => $formatted_url,
                    'interval_hours' => $interval
                ], ['id' => $existing->id]);
            } else {
                $wpdb->insert($table, [
                    'url' => $formatted_url,
                    'interval_hours' => $interval
                ]);
            }
        }
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }

    if (isset($_POST['url_pinger_edit_url'])) {
        check_admin_referer('url_pinger_edit_url');
        $id = intval($_POST['url_pinger_id']);
        $original_url = trim($_POST['url_pinger_url']);
        $interval = intval($_POST['url_pinger_interval']);
        if ($id && $original_url && $interval > 0) {
            $formatted_url = url_pinger_format_url($original_url);
            $norm = url_pinger_normalize_url($formatted_url);
            $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $table WHERE LOWER(REPLACE(REPLACE(REPLACE(url, 'http://', ''), 'https://', ''), 'www.', '')) = %s AND id != %d", $norm, $id));
            if ($existing) {
                $wpdb->update($table, [
                    'url' => $formatted_url,
                    'interval_hours' => $interval
                ], ['id' => $existing->id]);
                $wpdb->delete($table, ['id' => $id]);
            } else {
                $wpdb->update($table, [
                    'url' => $formatted_url,
                    'interval_hours' => $interval
                ], ['id' => $id]);
            }
        }
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }

    if (isset($_GET['url_pinger_delete_id'])) {
        check_admin_referer('url_pinger_delete_' . intval($_GET['url_pinger_delete_id']));
        $wpdb->delete($table, ['id' => intval($_GET['url_pinger_delete_id'])]);
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }

    if (isset($_GET['url_pinger_download_csv'])) {
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'url_pinger_download_csv')) {
            wp_die('Nonce verification failed.');
        }
        $results = $wpdb->get_results("SELECT url, interval_hours FROM $table");
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=url_pinger.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['URL', 'Interval (hours)']);
        foreach ($results as $row) {
            fputcsv($output, [$row->url, $row->interval_hours]);
        }
        fclose($output);
        exit;
    }

    // --- Download failed URLs CSV (NEW) ---
    if (isset($_GET['url_pinger_download_failed_csv'])) {
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'url_pinger_download_failed_csv')) {
            wp_die('Nonce verification failed.');
        }
        $results = $wpdb->get_results("SELECT url, last_ping_status, last_ping_result_time FROM $table WHERE last_ping_status = 'Fail'");
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename=url_pinger_failed.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['URL', 'Last Ping Status', 'Last Ping Time']);
        foreach ($results as $row) {
            fputcsv($output, [
                $row->url,
                $row->last_ping_status ? $row->last_ping_status : 'Never',
                $row->last_ping_result_time ? $row->last_ping_result_time : 'Never'
            ]);
        }
        fclose($output);
        exit;
    }

    if (isset($_POST['url_pinger_check_now'])) {
        check_admin_referer('url_pinger_check_now');
        url_pinger_schedule_check_now();
        wp_redirect(admin_url('admin.php?page=url-pinger&check_now_scheduled=1'));
        exit;
    }

    // --- Handle search ---
    if (isset($_GET['url_pinger_search_clear'])) {
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }

    // --- Handle failed filter clear ---
    if (isset($_GET['url_pinger_failed_clear'])) {
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }

    // --- Handle Ignore/Un-ignore actions ---
    if (isset($_GET['url_pinger_ignore_id'])) {
        $id = intval($_GET['url_pinger_ignore_id']);
        check_admin_referer('url_pinger_ignore_' . $id);
        $wpdb->update($table, ['is_ignored' => 1], ['id' => $id]);
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }
    if (isset($_GET['url_pinger_unignore_id'])) {
        $id = intval($_GET['url_pinger_unignore_id']);
        check_admin_referer('url_pinger_unignore_' . $id);
        $wpdb->update($table, ['is_ignored' => 0], ['id' => $id]);
        wp_redirect(admin_url('admin.php?page=url-pinger'));
        exit;
    }
}

/**
 * Send mail using wp_mail() and ensure WP Mail SMTP is used if present.
 */
function url_pinger_send_mail($to, $subject, $body, $headers = array())
{
    return wp_mail($to, $subject, $body, $headers);
}

// Schedule a one-time event for check now (runs as soon as cron can)
function url_pinger_schedule_check_now()
{
    if (!wp_next_scheduled('url_pinger_check_now_event')) {
        wp_schedule_single_event(time(), 'url_pinger_check_now_event');
    }
}

// Cron event for "Check Now"
add_action('url_pinger_check_now_event', 'url_pinger_check_now');
function url_pinger_check_now()
{
    global $wpdb;
    $table = url_pinger_get_table_name();
    $now = current_time('mysql');
    $admin_email = get_option('url_pinger_admin_email', get_option('admin_email'));
    $down_reports = [];
    $results = $wpdb->get_results("SELECT * FROM $table WHERE is_ignored = 0 ORDER BY interval_hours ASC, url ASC");

    foreach ($results as $row) {
        $status = url_pinger_ping_with_recheck($row->url);
        $wpdb->update(
            $table,
            [
                'last_ping_time' => $now,
                'last_ping_status' => $status ? 'Success' : 'Fail',
                'last_ping_result_time' => $now
            ],
            ['id' => $row->id]
        );
        if (!$status) {
            $down_reports[] = [
                'url' => $row->url,
                'time' => $now
            ];
        }
        if ($row !== end($results)) {
            sleep(3);
        }
    }

    if (count($down_reports) > 0 && is_email($admin_email)) {
        $subject = 'URL Pinger Alert: Website Down (Check Now)';
        $body = "The following website(s) appear to be down (from manual check):\n\n";
        foreach ($down_reports as $report) {
            $body .= 'URL: ' . $report['url'] . "\n";
            $body .= 'Checked at: ' . $report['time'] . "\n\n";
        }
        $body .= "Regards,\nURL Pinger (website live check)";
        url_pinger_send_mail($admin_email, $subject, $body);
    }
}

function url_pinger_admin_page()
{
    echo '<style>
    .button-danger{background:#dc3232;color:#fff;border-color:#a00 !important;}
    .button-danger:hover, .button-danger:focus {background:#a00;color:#fff;border-color:#600 !important;}
    .button-group-inline{display:inline-block;vertical-align:middle;} 
    .button-group-inline form{display:inline;} 
    .button-group-inline a{margin-right:8px!important;}
    .section-gap { margin-top: 60px !important; }
    .csv-info { background: #f8f8f8; color: #444; border: 1px solid #ddd; padding: 12px 16px; margin-bottom:20px; border-radius: 4px; font-size: 14px; }
    .url-pinger-table-striped tbody tr:nth-child(even) { background-color: #f9f9f9; }
    .url-pinger-table-striped tbody tr:nth-child(odd) { background-color: #fff; }
    .url-pinger-search-bar { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
    .url-pinger-search-bar input[type="text"] { width: 250px; }
    .button.button-danger { background: red !important; border-color: #a00 !important; color: #fff !important;}
    .button.button-danger:hover, .button.button-danger:focus {background:#a00 !important;color:#fff !important;border-color:#600 !important;}
    .url-pinger-bulk-form { margin-bottom: 24px; }
    .url-pinger-table-striped th:first-child, .url-pinger-table-striped td:first-child { text-align: center; width: 40px; }
    .ignored-row { background-color: #ffecec !important; }
    .url-pinger-refresh-btn { 
        background: #b2f5b2 !important; 
        color: #222 !important; 
        margin-bottom: 8px !important; 
        border-color: #85db85 !important; 
    }
    </style>';

    $admin_email = get_option('url_pinger_admin_email', get_option('admin_email'));

    $csv_message = '';
    $csv_message_type = 'success';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['url_pinger_csv'])) {
        if (!isset($_POST['url_pinger_csv_nonce']) || !wp_verify_nonce($_POST['url_pinger_csv_nonce'], 'url_pinger_csv')) {
            $csv_message = 'Nonce verification failed.';
            $csv_message_type = 'error';
        } else {
            $file = $_FILES['url_pinger_csv']['tmp_name'];
            if (($handle = fopen($file, 'r')) !== false) {
                global $wpdb;
                $table = url_pinger_get_table_name();
                $wpdb->query("TRUNCATE TABLE $table");
                $row = 0;
                $urls = [];
                while (($data = fgetcsv($handle)) !== false) {
                    if ($row == 0) {
                        $row++;
                        continue;
                    }
                    $original_url = trim($data[0]);
                    $interval = intval($data[1]);
                    if (!empty($original_url) && $interval > 0) {
                        $formatted_url = url_pinger_format_url($original_url);
                        $norm = url_pinger_normalize_url($formatted_url);
                        $urls[$norm] = [
                            'original' => $formatted_url,
                            'interval' => $interval
                        ];
                    }
                    $row++;
                }
                fclose($handle);
                foreach ($urls as $norm => $vals) {
                    $wpdb->insert($table, [
                        'url' => $vals['original'],
                        'interval_hours' => $vals['interval']
                    ]);
                }
                $csv_message = 'CSV imported successfully. URLs were normalized to "https://domain.com" format. Duplicate URLs (ignoring protocol/www) were merged; last occurrence is kept.';
                $csv_message_type = 'success';
            } else {
                $csv_message = 'Error reading the uploaded CSV file.';
                $csv_message_type = 'error';
            }
        }
    }

    $delete_all_message = '';
    if (isset($_GET['url_pinger_delete_all']) && $_GET['url_pinger_delete_all'] === '1') {
        $delete_all_message = '<div class="notice notice-success is-dismissible"><p>All URLs have been deleted.</p></div>';
    }

    $bulk_deleted_message = '';
    if (isset($_GET['bulk_deleted']) && $_GET['bulk_deleted'] === '1') {
        $bulk_deleted_message = '<div class="notice notice-success is-dismissible"><p>Selected URLs have been deleted.</p></div>';
    }

    $search_query = isset($_GET['url_pinger_search']) ? trim(sanitize_text_field($_GET['url_pinger_search'])) : '';
    $show_failed = isset($_GET['url_pinger_failed']) && $_GET['url_pinger_failed'] === '1';

    global $wpdb;
    $table = url_pinger_get_table_name();
    $has_ping_results = (bool) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE last_ping_status IS NOT NULL AND last_ping_status != ''");

?>
    <div class="wrap">
        <h1>URL Pinger (website live check)</h1>
        <div style="font-size:13px; font-style:italic; color:#666; margin-bottom: 18px;">
            Some hosting providers may not allow incoming pings, they will show as "Fail" even though the websites may be working.
        </div>
        <div style="display: flex; align-items: flex-end; justify-content: space-between;">
            <div>
                <h2 style="display: inline-block; margin-right: 15px;">Current URLs</h2>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
                <a href="<?php echo esc_url(admin_url('admin.php?page=url-pinger')); ?>" class="button url-pinger-refresh-btn">Refresh Page</a>
                <form method="get" class="url-pinger-search-bar" action="<?php echo esc_url(admin_url('admin.php')); ?>">
                    <input type="hidden" name="page" value="url-pinger">
                    <input type="text" name="url_pinger_search" placeholder="Search URLs..." value="<?php echo esc_attr($search_query); ?>">
                    <button class="button button-primary" type="submit">Search</button>
                    <?php if (!empty($search_query)) : ?>
                        <a href="<?php echo esc_url(remove_query_arg('url_pinger_search', admin_url('admin.php?page=url-pinger&url_pinger_search_clear=1'))); ?>" class="button">Clear search</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
        <?php
        $url_count = url_pinger_display_table($search_query, $show_failed, true);
        ?>
        <?php if ($url_count > 0): ?>
            <div class="button-group-inline" style="margin: 16px 0 0 0;">
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=url-pinger&url_pinger_download_csv=1'), 'url_pinger_download_csv')); ?>">Download URLs as CSV</a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=url-pinger&url_pinger_download_failed_csv=1'), 'url_pinger_download_failed_csv')); ?>">Download failed URLs list</a>
                <?php if ($has_ping_results): ?>
                    <?php if (!$show_failed): ?>
                        <a class="button" href="<?php echo esc_url(add_query_arg('url_pinger_failed', '1', admin_url('admin.php?page=url-pinger'))); ?>">Show Failed URLs</a>
                    <?php else: ?>
                        <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=url-pinger&url_pinger_failed_clear=1')); ?>">Clear Failed Filter</a>
                    <?php endif; ?>
                <?php endif; ?>
                <form method="post" style="display:inline;">
                    <?php wp_nonce_field('url_pinger_delete_all'); ?>
                    <button type="submit" name="url_pinger_delete_all" class="button button-danger" onclick="return confirm('Are you sure you want to delete ALL URLs?');">Delete All</button>
                </form>
            </div>
        <?php endif; ?>
        <hr>
        <?php
        if (isset($_GET['check_now_done'])) {
            echo '<div class="notice notice-success is-dismissible"><p>Check Now completed. Results are updated below.</p></div>';
        }
        if (isset($_GET['check_now_scheduled'])) {
            echo '<div class="notice notice-info is-dismissible"><p>Check Now has been scheduled and is running in the background. Please refresh this page by pressing the green "Refresh Page" button after a short while to view the updated results.</p></div>';
        }
        if (!empty($csv_message)) {
            echo '<div class="notice notice-' . esc_attr($csv_message_type) . ' is-dismissible"><p>' . esc_html($csv_message) . '</p></div>';
        }
        if (!empty($delete_all_message)) {
            echo $delete_all_message;
        }
        if (!empty($bulk_deleted_message)) {
            echo $bulk_deleted_message;
        }
        ?>
        <?php if ($url_count > 0): ?>
            <form method="post" style="margin-bottom: 20px; margin-top:30px;">
                <?php wp_nonce_field('url_pinger_check_now'); ?>
                <button type="submit" name="url_pinger_check_now" class="button button-primary">Check Now</button>
                <span style="margin-left: 8px; color: #555;">(Ping all URLs now, runs in the background. Refresh the page after a while for results. Email is sent if any are down.)</span>
            </form>
        <?php endif; ?>

        <h2 class="section-gap">Add New URL</h2>
        <form method="post" style="margin-bottom: 20px;">
            <?php wp_nonce_field('url_pinger_add_url'); ?>
            <input type="url" name="url_pinger_url" placeholder="https://example.com" required style="width: 300px;">
            <input type="number" name="url_pinger_interval" placeholder="Interval (hours)" min="1" required style="width: 140px;">
            <button type="submit" name="url_pinger_add_url" class="button button-secondary">Add URL</button>
        </form>

        <h2 class="section-gap">Import URLs from CSV</h2>
        <div class="csv-info">
            <strong>CSV format:</strong><br>
            The CSV file must contain the following columns in this order:<br>
            <code>URL, Interval (hours)</code><br><br>
            <strong>Header row is required</strong> (example below):<br>
            <code>
                URL,Interval (hours)<br>
                https://example.com,12<br>
                https://www.example2.com,6<br><br>
            </code>
            <ul style="margin:8px 0 0 0;">
                <li>URLs will be normalized to the format <code>https://domain.com</code> or <code>https://www.domain.com</code> (no trailing slash, no path/query).</li>
                <li>Duplicate URLs (ignoring protocol/www) will be merged; only the last occurrence is kept.</li>
                <li>The <strong>Interval (hours)</strong> must be a positive integer.</li>
            </ul>
        </div>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('url_pinger_csv', 'url_pinger_csv_nonce'); ?>
            <input type="file" name="url_pinger_csv" accept=".csv" required>
            <button type="submit" class="button button-primary">Upload CSV</button>
        </form>

        <h2 class="section-gap">Notification Email</h2>
        <form method="post" style="margin-bottom: 20px;">
            <?php wp_nonce_field('url_pinger_save_email'); ?>
            <input type="email" name="url_pinger_admin_email" value="<?php echo esc_attr($admin_email); ?>" required style="width: 300px;">
            <button type="submit" name="url_pinger_save_email" class="button button-secondary">Save Email</button>
        </form>
    </div>
    <?php
}

function url_pinger_display_table($search_query = '', $show_failed = false, $bulk_form = false)
{
    global $wpdb;
    $table = url_pinger_get_table_name();

    $per_page = 15;
    $current_page = isset($_GET['p']) ? max(1, intval($_GET['p'])) : 1;

    $where_sql = '';
    $params = array();

    if (!empty($search_query)) {
        $where_sql = "WHERE url LIKE %s";
        $params[] = '%' . $wpdb->esc_like($search_query) . '%';
    }

    if ($show_failed) {
        if (!empty($where_sql)) {
            $where_sql .= " AND last_ping_status = 'Fail'";
        } else {
            $where_sql = "WHERE last_ping_status = 'Fail'";
        }
    }

    $count_sql = "SELECT COUNT(*) FROM $table " . $where_sql;
    $total = $wpdb->get_var($wpdb->prepare($count_sql, ...$params));

    $offset = ($current_page - 1) * $per_page;
    $order_sql = "ORDER BY interval_hours ASC, url ASC";
    $limit_sql = "LIMIT %d OFFSET %d";
    $params2 = $params;
    $params2[] = $per_page;
    $params2[] = $offset;
    $select_sql = "SELECT * FROM $table " . $where_sql . " $order_sql $limit_sql";
    $results = $wpdb->get_results($wpdb->prepare($select_sql, ...$params2));

    if ($total == 0) {
        echo '<div style="margin:18px 0 18px 0; font-weight:bold;">No URLs Found</div>';
        return 0;
    }

    if (isset($_GET['url_pinger_edit_id'])) {
        $id = intval($_GET['url_pinger_edit_id']);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $id));
        if ($row) {
    ?>
            <h2>Edit URL</h2>
            <form method="post" style="margin-bottom: 20px;">
                <?php wp_nonce_field('url_pinger_edit_url'); ?>
                <input type="hidden" name="url_pinger_id" value="<?php echo esc_attr($row->id); ?>">
                <input type="url" name="url_pinger_url" value="<?php echo esc_attr($row->url); ?>" required style="width: 300px;">
                <input type="number" name="url_pinger_interval" value="<?php echo esc_attr($row->interval_hours); ?>" min="1" required style="width: 140px;">
                <button type="submit" name="url_pinger_edit_url" class="button button-secondary">Update URL</button>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=url-pinger')); ?>">Cancel</a>
            </form>
<?php
        }
    }

    if ($bulk_form) {
        echo '<form method="post" class="url-pinger-bulk-form" onsubmit="return confirm(\'Delete selected URLs?\');">';
        wp_nonce_field('url_pinger_bulk_delete');
    }

    echo '<table class="widefat url-pinger-table-striped"><thead>
        <tr>';
    if ($bulk_form) {
        echo '<th><input type="checkbox" onclick="var cbs=document.querySelectorAll(\'.url-pinger-bulk-checkbox\');for(var i=0;i<cbs.length;i++){cbs[i].checked=this.checked;}"></th>';
    }
    echo '<th>URL</th>
            <th>Interval (hours)</th>
            <th>Last Ping Status</th>
            <th>Last Ping Time</th>
            <th>Actions</th>
        </tr>
    </thead><tbody>';
    foreach ($results as $row) {
        $ignored_class = !empty($row->is_ignored) ? 'ignored-row' : '';
        echo '<tr class="' . $ignored_class . '">';
        if ($bulk_form) {
            echo '<td><input type="checkbox" class="url-pinger-bulk-checkbox" name="url_pinger_ids[]" value="' . esc_attr($row->id) . '"></td>';
        }
        echo '
            <td>' . esc_html($row->url) . '</td>
            <td>' . esc_html($row->interval_hours) . '</td>
            <td>' . ($row->last_ping_status ? esc_html($row->last_ping_status) : 'Never') . '</td>
            <td>' . ($row->last_ping_result_time ? esc_html($row->last_ping_result_time) : 'Never') . '</td>
            <td>
                <a class="button button-small" href="' . esc_url(admin_url('admin.php?page=url-pinger&url_pinger_edit_id=' . $row->id)) . '">Edit</a>
                <a class="button button-small" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=url-pinger&url_pinger_delete_id=' . $row->id), 'url_pinger_delete_' . $row->id)) . '" onclick="return confirm(\'Delete this URL?\');">Delete</a>
                <a class="button button-small" href="' . esc_url($row->url) . '" target="_blank" rel="noopener">Visit URL</a>
                ';
        if (empty($row->is_ignored)) {
            echo '<a class="button button-small" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=url-pinger&url_pinger_ignore_id=' . $row->id), 'url_pinger_ignore_' . $row->id)) . '" style="background:#ccc;color:#333;margin-left:2px;" title="Ignore this URL from being checked">Ignore URL</a>';
        } else {
            echo '<a class="button button-small" href="' . esc_url(wp_nonce_url(admin_url('admin.php?page=url-pinger&url_pinger_unignore_id=' . $row->id), 'url_pinger_unignore_' . $row->id)) . '" style="background:#ffe066;color:#000;margin-left:2px;" title="Un-ignore this URL">Un-ignore</a>';
        }
        echo '
            </td>
        </tr>';
    }
    echo '</tbody></table>';

    if ($bulk_form) {
        echo '<button type="submit" name="url_pinger_bulk_delete" class="button button-danger" style="margin-top:8px;">Delete Selected</button>';
        echo '</form>';
    }

    $num_pages = ceil($total / $per_page);
    if ($num_pages > 1) {
        echo '<div style="margin-top:12px;">';
        if ($current_page > 1) {
            $page_args = $_GET;
            $page_args['p'] = $current_page - 1;
            echo '<a style="margin-right:8px;" href="' . esc_url(add_query_arg($page_args, admin_url('admin.php'))) . '">Previous</a>';
        } else {
            echo '<span style="margin-right:8px;color:#aaa;">Previous</span>';
        }
        echo 'Pages: ';
        for ($i = 1; $i <= $num_pages; $i++) {
            $page_args = $_GET;
            $page_args['p'] = $i;
            if ($i == $current_page) {
                echo '<strong>' . $i . '</strong>';
            } else {
                echo '<a href="' . esc_url(add_query_arg($page_args, admin_url('admin.php'))) . '">' . $i . '</a>';
            }
            if ($i < $num_pages) echo ', ';
        }
        if ($current_page < $num_pages) {
            $page_args = $_GET;
            $page_args['p'] = $current_page + 1;
            echo ' <a style="margin-left:8px;" href="' . esc_url(add_query_arg($page_args, admin_url('admin.php'))) . '">Next</a>';
        } else {
            echo ' <span style="margin-left:8px;color:#aaa;">Next</span>';
        }
        echo '</div>';
    }

    return $total;
}

if (!wp_next_scheduled('url_pinger_cron_event')) {
    wp_schedule_event(time(), 'five_minutes', 'url_pinger_cron_event');
}
add_filter('cron_schedules', function ($schedules) {
    $schedules['five_minutes'] = [
        'interval' => 300,
        'display' => __('Every Five Minutes')
    ];
    return $schedules;
});

add_action('url_pinger_cron_event', 'url_pinger_process_pings');

function url_pinger_process_pings()
{
    global $wpdb;
    $table = url_pinger_get_table_name();
    $now = current_time('mysql');
    $admin_email = get_option('url_pinger_admin_email', get_option('admin_email'));
    $down_reports = [];

    $urls = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table
         WHERE (last_ping_time IS NULL
            OR TIMESTAMPDIFF(HOUR, last_ping_time, %s) >= interval_hours)
            AND is_ignored = 0
         ORDER BY interval_hours ASC, url ASC, last_ping_time ASC",
        $now
    ));

    foreach ($urls as $row) {
        $status = url_pinger_ping_with_recheck($row->url);
        $wpdb->update(
            $table,
            [
                'last_ping_time' => $now,
                'last_ping_status' => $status ? 'Success' : 'Fail',
                'last_ping_result_time' => $now
            ],
            ['id' => $row->id]
        );
        if (!$status) {
            $down_reports[] = [
                'url' => $row->url,
                'time' => $now
            ];
        }
        break;
    }

    if (!empty($down_reports) && is_email($admin_email)) {
        $subject = 'URL Pinger Alert: Website Down';
        $body = "The following website(s) appear to be down:\n\n";
        foreach ($down_reports as $report) {
            $body .= 'URL: ' . $report['url'] . "\n";
            $body .= 'Checked at: ' . $report['time'] . "\n\n";
        }
        $body .= "Regards,\nURL Pinger (website live check)";
        url_pinger_send_mail($admin_email, $subject, $body);
    }
}

function url_pinger_ping($url)
{
    $args = [
        'timeout' => 10,
        'redirection' => 3,
        'httpversion' => '1.1',
        'blocking' => true,
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (compatible; URLPinger/1.12; +https://codesmart.online)'
        ],
    ];
    $response = wp_remote_get($url, $args);
    if (is_wp_error($response)) return false;
    $code = wp_remote_retrieve_response_code($response);
    return ($code >= 200 && $code < 400);
}

function url_pinger_ping_with_recheck($url)
{
    $first = url_pinger_ping($url);
    if ($first) return true;
    sleep(1);
    $second = url_pinger_ping($url);
    return $second ? true : false;
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'url_pinger_plugin_action_links');
function url_pinger_plugin_action_links($links)
{
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=url-pinger')) . '">' . esc_html__('Configure', 'url-pinger') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
?>