<?php
// If uninstall not called from WordPress, exit
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

global $wpdb;

// Use the same logic as in main plugin to get the table name
$table = $wpdb->prefix . (strlen($wpdb->prefix . 'url_pinger') > 64 ? 'urlpgr' : 'url_pinger');

// Remove custom table
$wpdb->query("DROP TABLE IF EXISTS $table");

// Remove options
delete_option('url_pinger_admin_email');
